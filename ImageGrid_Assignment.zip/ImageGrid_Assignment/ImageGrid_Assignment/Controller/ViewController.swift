//
//  ViewController.swift
//  ImageGrid_Assignment
//
//  Created by Tejashree on 06/05/24.
//

import UIKit
import SwiftUI

class ViewController: UIViewController {
    
    static var reuseIdentifier = "ViewController"
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var imageData: [GridData] = []
    var imageCache = NSCache<AnyObject, AnyObject>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self
        collectionView.delegate = self
        fetchData()
    }
    
    // MARK: -  Functions
    
    func displayError(message: String) {
        DispatchQueue.main.async {
            let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func fetchData() {
        let jsonUrlString = "https://acharyaprashant.org/api/v2/content/misc/media-coverages?limit=100"
        
        guard let url = URL(string: jsonUrlString) else {
            displayError(message: "Invalid URL")
            return
        }
        
        URLSession.shared.dataTask(with: url) { [weak self] (data, response, error) in
            guard let self = self, let data = data, error == nil else { return }
            if let error = error {
                self.displayError(message: error.localizedDescription)
                return
            }
            
            do {
                let dataAsString = String(data: data, encoding: .utf8)
                let imageData = try JSONDecoder().decode([GridData].self, from: data)
                
                DispatchQueue.main.async {
                    self.imageData = imageData
                    self.collectionView.reloadData()
                }
            } catch {
                self.displayError(message: "Error decoding data: \(error.localizedDescription)")
                print("Error decoding data: \(error)")
            }
        }.resume()
    }
}

// MARK: - Extension CollectionView DataSource and Delegate methods

extension ViewController: UICollectionViewDataSource,UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var task: URLSessionDataTask!
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectionViewCell.reuseIdentifier, for: indexPath) as! CollectionViewCell
        
        cell.imageView?.image = nil
        cell.imageView.layer.borderWidth = 1
        cell.imageView.layer.cornerRadius = 3
        cell.imageView.layer.borderColor = UIColor.black.cgColor
        
        let thumbnail = imageData[indexPath.row].thumbnail
        if let domain = thumbnail?.domain, let basePath = thumbnail?.basePath, let key = thumbnail?.key {
            
            let imageURLString = "\(domain)/\(basePath)/0/\(key)"
            if let task = task{
                task.cancel()
            }
            
            if let imageURL = URL(string: imageURLString) {
                if let cachedData = self.imageCache.object(forKey: imageURL.absoluteString as AnyObject) as? Data,
                   let image = UIImage(data: cachedData) {
                    cell.imageView?.image = image
                } else {
                    task = URLSession.shared.dataTask(with: imageURL) { (data, response, error) in
                        guard let data = data, error == nil else { return }
                        
                        self.imageCache.setObject(data as AnyObject, forKey: imageURL.absoluteString as AnyObject)
                        
                        DispatchQueue.main.async {
                            if let image = UIImage(data: data) {
                                cell.imageView?.image = image
                                cell.imageView.contentMode = .scaleAspectFit
                                cell.layoutIfNeeded()
                                
                            }
                        }
                    }
                    task.resume()
                }
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: 112 , height: 112)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 3
    }
}


