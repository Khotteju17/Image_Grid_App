//
//  GridData.swift
//  ImageGrid_Assignment
//
//  Created by Tejashree on 06/05/24.
//

import Foundation
import UIKit

struct GridData: Decodable{
    
    var id: String
    var title: String?
    var language: String?
    var thumbnail: Thumbnail?
    var mediaType: Int
    var coverageURL: String?
    var publishedAt: String?
    var publishedBy: String?
    var backupDetails: BackupDetails?
    
}

struct BackupDetails: Codable{
    var pdfLink: String?
    var screenshotURL: String?
}
