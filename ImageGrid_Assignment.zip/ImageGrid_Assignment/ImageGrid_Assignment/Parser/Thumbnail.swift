//
//  Thumbnail.swift
//  ImageGrid_Assignment
//
//  Created by Tejashree on 06/05/24.
//

import Foundation

struct Thumbnail: Codable{
    var id: String?
    var version:Int
    var domain: String?
    var basePath:String?
    var key:String?
    var qualities:[Int]
    var aspectRatio:Double
}

