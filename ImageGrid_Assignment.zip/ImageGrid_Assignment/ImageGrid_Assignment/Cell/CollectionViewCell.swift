//
//  CollectionViewCell.swift
//  ImageGrid_Assignment
//
//  Created by Tejashree on 06/05/24.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    static var reuseIdentifier = "CollectionViewCell"
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func prepareForReuse() {
         super.prepareForReuse()
         self.imageView.image = nil
     }
}
