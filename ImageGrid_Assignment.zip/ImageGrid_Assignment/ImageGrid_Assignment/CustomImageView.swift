//
//  CustomImageView.swift
//  ImageGrid_Assignment
//
//  Created by Tejashree on 06/05/24.
//

import Foundation
import UIKit

class CustomImageView: UIImageView{

}
